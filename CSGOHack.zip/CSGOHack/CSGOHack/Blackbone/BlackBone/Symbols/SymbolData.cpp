#pragma once
#include "SymbolData.h"

namespace blackbone
{
	SymbolData g_symbols;
}